#!/bin/bash
#install curl first 
#then use functionalities

sudo apt-get install curl

curl wttr.in
