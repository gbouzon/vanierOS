#!/bin/bash

#installing snapd software

sudo apt-get install snapd

snap install --beta mysql

snap install greenfoot

snap install code

snap install spotify

snap install eclipse

snap install android-studio

snap install netbeans

snap install firefox

snap install blender

snap install default-jdk
